# 🚗 Parc Auto DRT Sfax — PWA

Application de gestion du parc automobile DRT Sfax.
Installable sur Android/iOS comme une application native.

---

## 📁 Structure des fichiers

```
parc_auto_drt_sfax/
├── index.html        ← Application principale
├── manifest.json     ← Configuration PWA
├── sw.js             ← Service Worker (mode hors-ligne)
├── icons/            ← Icônes de l'application
│   ├── icon-72x72.png
│   ├── icon-96x96.png
│   ├── icon-128x128.png
│   ├── icon-144x144.png
│   ├── icon-152x152.png
│   ├── icon-192x192.png
│   ├── icon-384x384.png
│   └── icon-512x512.png
└── README.md
```

---

## 🚀 Déploiement sur GitHub Pages (GRATUIT)

### Étape 1 — Créer un compte GitHub
→ https://github.com (gratuit)

### Étape 2 — Créer un nouveau dépôt
1. Cliquer sur **"New repository"**
2. Nom : `parc-auto-drt`
3. Cocher **"Public"**
4. Cliquer **"Create repository"**

### Étape 3 — Uploader les fichiers
1. Cliquer **"uploading an existing file"**
2. Glisser-déposer TOUS les fichiers du dossier (index.html, manifest.json, sw.js, et le dossier icons/)
3. Cliquer **"Commit changes"**

### Étape 4 — Activer GitHub Pages
1. Aller dans **Settings** → **Pages**
2. Source : **"Deploy from a branch"**
3. Branch : **main** → **/ (root)**
4. Cliquer **Save**

### Étape 5 — Accéder à l'application
Après 2-3 minutes, l'URL sera :
```
https://[votre-username].github.io/parc-auto-drt/
```

---

## 📱 Installation sur Android

1. Ouvrir l'URL dans **Chrome Android**
2. Un bouton **"Installer l'application"** apparaît automatiquement
3. Ou : Menu Chrome ⋮ → **"Ajouter à l'écran d'accueil"**
4. L'icône voiture apparaît sur le bureau du téléphone ✅

## 📱 Installation sur iPhone/iPad

1. Ouvrir l'URL dans **Safari**
2. Bouton Partager (carré avec flèche) → **"Sur l'écran d'accueil"**
3. L'icône voiture apparaît sur le bureau ✅

---

## 🔐 Accès

| Rôle | Identifiant | Mot de passe |
|------|-------------|--------------|
| Admin | admin | drt2024 |
| Conducteur | — | Entrer la matricule directement |

---

## ✅ Fonctionnalités

- Mode hors-ligne (Service Worker)
- Splash screen au démarrage
- Icône sur écran d'accueil
- Alertes vidange / chaîne / visite technique
- Modifications admin visibles instantanément côté conducteur
- Données sauvegardées localement (localStorage)
